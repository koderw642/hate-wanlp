// Dashboard.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Typography,
  Box,
} from '@mui/material';
import UserProfileMenu from '../components/UserProfileMenu';
import StatsCard from '../components/StatsCard';
import HateStats from '../components/HateStats';
import HateSpeechChart from '../components/HateSpeechChart';
import Topic from '../components/Topic';
import HateCommentsPerPostChart from '../components/PostChart';
import RecentComments from '../components/RecentComments';
import axios from 'axios';
import Swal from 'sweetalert2';

const CommentItem = ({ comment, onDelete, onReport, onApprove, showActions = true, showStatus = false }) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const [isReporting, setIsReporting] = useState(false);
  const [isApproving, setIsApproving] = useState(false);

  const handleAction = async (action, id) => {
    try {
      if (action === 'delete') setIsDeleting(true);
      if (action === 'report') setIsReporting(true);
      if (action === 'approve') setIsApproving(true);

      await action(id);
    } finally {
      setIsDeleting(false);
      setIsReporting(false);
      setIsApproving(false);
    }
  };

  return (
    <li className={`comment ${comment.hate_speech === 'Hate Speech' ? 'hate-comment' : ''}`}>
      <div className="comment-content">
        <p>{comment.text}</p>
        <div className="comment-meta">
          <span>{new Date(comment.created_utc * 1000).toLocaleString()}</span>
          {showStatus && <span>Status: {comment.hate_speech}</span>}
          <span>Topic: {comment.topic}</span>
          <a href={comment.url} target="_blank" rel="noopener noreferrer">View</a>
        </div>
      </div>
      {showActions && (
        <div className="comment-actions">
          <button onClick={() => handleAction(onDelete, comment.id)} className="btn-delete" disabled={isDeleting}>
            {isDeleting ? 'Deleting...' : 'Delete'}
          </button>
          <button onClick={() => handleAction(onReport, comment.id)} className="btn-report" disabled={isReporting}>
            {isReporting ? 'Reporting...' : 'Report'}
          </button>
          <button onClick={() => handleAction(onApprove, comment.id)} className="btn-approve" disabled={isApproving}>
            {isApproving ? 'Approving...' : 'Approve'}
          </button>
        </div>
      )}
    </li>
  );
};

const PostItem = ({ post, onDelete, onReport }) => (
  <div className="post-item">
    <div className={`post-header ${post.post.hate_speech === 'Hate Speech' ? 'hate-post' : ''}`}>
      <h3>{post.post.title}</h3>
      <p>{post.post.text.substring(0, 100)}{post.post.text.length > 100 ? '...' : ''}</p>
      <div className="post-meta">
        <span>Status: {post.post.hate_speech}</span>
        <span>Topic: {post.post.topic}</span>
        <a href={post.post.url} target="_blank" rel="noopener noreferrer">View on Reddit</a>
      </div>
    </div>
    {post.hate_comments.length > 0 && (
      <div className="post-hate-comments">
        <h4>Hate Comments in this Post ({post.hate_comments.length})</h4>
        <ul className="comments-list">
          {post.hate_comments.map((comment) => (
            <CommentItem
              key={comment.id}
              comment={comment}
              onDelete={onDelete}
              onReport={onReport}
              showStatus={false}
            />
          ))}
        </ul>
      </div>
    )}
  </div>
);

function Dashboard() {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({
    totalPosts: 0,
    totalComments: 0,
    hateComments: 0,
    hatePercentage: 0,
  });
  const [comments, setComments] = useState([]);
  const [hateComments, setHateComments] = useState([]);
  const [posts, setPosts] = useState([]);
  const navigate = useNavigate();

  // Remove duplicate comments
  const removeDuplicates = (comments) => {
    const seen = new Set();
    return comments.filter((comment) => {
      const duplicate = seen.has(comment.id);
      seen.add(comment.id);
      return !duplicate;
    });
  };

  // Handle comment deletion
  const handleDelete = async (commentId) => {
    try {
      const token = localStorage.getItem('reddit_token');
      if (!token) throw new Error("No access token found. Please log in again.");

      const confirm = await Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      });

      if (!confirm.isConfirmed) return;

      const response = await axios.post(
        'http://localhost:8000/reddit/delete-comment/',
        { comment_id: `t1_${commentId}` },
        { headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'HateSpeechDetector/1.0' } }
      );

      if (response.data.status === 'success') {
        updateStateAfterAction(commentId);
        Swal.fire({ title: "Deleted!", text: "The comment has been deleted.", icon: "success" });
      } else {
        throw new Error(response.data.message || "Failed to delete comment");
      }
    } catch (err) {
      console.error("Delete error:", err);
      Swal.fire({ title: "Error!", text: err.message || "Failed to delete comment", icon: "error" });
    }
  };

  // Handle comment reporting
  const handleReport = async (commentId) => {
    try {
      const token = localStorage.getItem('reddit_token');
      if (!token) throw new Error("No access token found. Please log in again.");

      const confirm = await Swal.fire({
        title: "Are you sure?",
        text: "Do you want to report this comment?",
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, report it!"
      });

      if (!confirm.isConfirmed) return;

      const response = await axios.post(
        'http://localhost:8000/reddit/report-comment/',
        { comment_id: `t1_${commentId}` },
        { headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'HateSpeechDetector/1.0' } }
      );

      if (response.data.status === 'success') {
        updateStateAfterAction(commentId);
        Swal.fire({ title: "Reported!", text: "The comment has been reported.", icon: "success" });
      } else {
        throw new Error(response.data.message || "Failed to report comment");
      }
    } catch (err) {
      console.error("Report error:", err);
      Swal.fire({ title: "Error!", text: err.message || "Failed to report comment", icon: "error" });
    }
  };

  // Handle comment approval
  const handleApprove = async (commentId) => {
    try {
      const token = localStorage.getItem('reddit_token');
      if (!token) throw new Error("No access token found. Please log in again.");

      const confirm = await Swal.fire({
        title: "Are you sure?",
        text: "Do you want to approve this comment?",
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, approve it!"
      });

      if (!confirm.isConfirmed) return;

      const response = await axios.post(
        'http://localhost:8000/reddit/approve-comment/',
        { comment_id: `t1_${commentId}` },
        { headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'HateSpeechDetector/1.0' } }
      );

      if (response.data.status === 'success') {
        updateStateAfterAction(commentId);
        Swal.fire({ title: "Approved!", text: "The comment has been approved.", icon: "success" });
      } else {
        throw new Error(response.data.message || "Failed to approve comment");
      }
    } catch (err) {
      console.error("Approve error:", err);
      Swal.fire({ title: "Error!", text: err.message || "Failed to approve comment", icon: "error" });
    }
  };

  // Update state after an action (delete, report, approve)
  const updateStateAfterAction = (commentId) => {
    setComments((prev) => prev.filter((c) => c.id !== commentId));
    setHateComments((prev) => prev.filter((c) => c.id !== commentId));
    setPosts((prev) =>
      prev.map((post) => ({
        ...post,
        comments: post.comments.filter((c) => c.id !== commentId),
        hate_comments: post.hate_comments.filter((c) => c.id !== commentId),
      }))
    );
    setStats((prev) => ({
      ...prev,
      totalComments: prev.totalComments - 1,
      hateComments: prev.hateComments - (hateComments.some((c) => c.id === commentId) ? 1 : 0),
      hatePercentage:
        ((prev.hateComments - (hateComments.some((c) => c.id === commentId) ? 1 : 0)) /
          (prev.totalComments - 1)) *
          100 || 0,
    }));
  };

  // Fetch all user data
  const fetchAllData = async (token, user) => {
    try {
      setLoading(true);
      setError(null);

      const response = await axios.get('http://localhost:8000/analyze-me/', {
        headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'HateSpeechDetector/1.0' },
      });

      const data = response.data;
      const allComments = removeDuplicates([
        ...data.standalone_comments,
        ...data.posts_with_comments.flatMap((post) => post.comments),
      ]);
      const allHateComments = removeDuplicates([
        ...data.all_hate_comments,
        ...data.posts_with_comments.flatMap((post) => post.hate_comments),
      ]);

      setUserData({
        name: data.user.name,
        avatar: data.user.icon_img || 'default-profile.png',
        total_karma: data.user.total_karma,
        joinDate: new Date(data.user.created_utc * 1000).toLocaleDateString(),
      });
      setStats({
        totalPosts: data.posts_with_comments.length,
        totalComments: allComments.length,
        hateComments: allHateComments.length,
        hatePercentage: data.stats.hate_percentage,
      });
      setComments(allComments);
      setHateComments(allHateComments);
      setPosts(data.posts_with_comments);
    } catch (err) {
      console.error('Data fetching error:', err);
      setError('Failed to load data. Please try again.');
      if (err.response?.status === 401) {
        localStorage.removeItem('reddit_token');
        localStorage.removeItem('reddit_user');
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  };

  // Initialize authentication
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const token = params.get('access_token');

        if (token) {
          const user = {
            name: params.get('user_name'),
            id: params.get('user_id'),
            icon_img: params.get('icon_img'),
          };
          localStorage.setItem('reddit_token', token);
          localStorage.setItem('reddit_user', JSON.stringify(user));
          window.history.replaceState({}, document.title, '/dashboard');
          await fetchAllData(token, user);
        } else {
          const storedToken = localStorage.getItem('reddit_token');
          const storedUser = localStorage.getItem('reddit_user');
          if (storedToken && storedUser) {
            await fetchAllData(storedToken, JSON.parse(storedUser));
          } else {
            navigate('/login');
          }
        }
      } catch (err) {
        console.error('Initialization error:', err);
        setError('Failed to initialize. Please login again.');
        navigate('/login');
      }
    };

    initializeAuth();
  }, [navigate]);

  // Loading state
  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <div className="error">Error: {error}</div>;
  if (!userData) return <div className="error">No user data available</div>;

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 'bold' }}>Dashboard</Typography>
        </Box>
        <UserProfileMenu user={userData} />
      </Box>

      <Box sx={{ display: 'flex', gap: 3, mb: 4 }}>
        <HateStats total={stats.totalComments} hate={stats.hateComments} />
        <StatsCard type="posts" count={stats.totalPosts} />
        <StatsCard type="comments" count={stats.totalComments} />
      </Box>

      <Box sx={{ display: 'flex', gap: 3, mb: 4 }}>
        <Box sx={{ flex: 1 }}>
          <RecentComments
            comments={hateComments.map((comment) => ({
              id: comment.id,
              text: comment.text,
              topic: comment.topic,
              timestamp: comment.created_utc * 1000,
              severity: comment.hate_speech === 'Hate Speech' ? 'high' : 'medium',
            }))}
            onDelete={handleDelete}
            onReport={handleReport}
          />
        </Box>
        <Box sx={{ flex: 1 }}>
          <HateSpeechChart total={stats.totalComments} hate={stats.hateComments} />
          <br />
          <HateCommentsPerPostChart posts={posts} />
        </Box>
      </Box>

      <Box sx={{ display: 'flex', gap: 3, mb: 4 }}>
        <Box sx={{ flex: 1 }}>
          <Topic posts={posts} hateComments={hateComments} />
        </Box>
      </Box>
    </Box>
  );
}

export default Dashboard;
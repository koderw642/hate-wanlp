import React from 'react';
import { 
  Card, 
  CardHeader, 
  Box, 
  Typography, 
  Chip, 
  Avatar,
  Button,
  keyframes,
  styled
} from '@mui/material';
import WarningIcon from '@mui/icons-material/Warning';
import { formatDistanceToNow } from 'date-fns';

// Styled component for the comment card
const CommentCard = styled(Box)(({ theme }) => ({
  padding: theme.spacing(2.5),
  borderRadius: 12,
  backgroundColor: '#fff',
  boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
  border: '1px solid rgba(0,0,0,0.04)',
  transition: 'all 0.3s ease',
  position: 'relative',
  overflow: 'hidden',
  '&:hover': {
    transform: 'translateY(-3px)',
    boxShadow: '0 6px 16px rgba(0,0,0,0.1)',
    borderColor: 'rgba(0,0,0,0.08)'
  },
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    width: '4px',
    background: 'inherit'
  }
}));

// Animation keyframes
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const getSeverityColor = (severity) => {
  switch(severity) {
    case 'high': return '#3b2969';
    case 'medium': return '#FFA726';
    default: return '#66BB6A';
  }
};

export default function RecentComments({ comments = [], onDelete, onReport }) {
  return (
    <Card sx={{ 
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      borderRadius: 3,
      boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
      overflow: 'hidden',
      border: '1px solid rgba(0,0,0,0.05)'
    }}>
      {/* Card Header */}
      <CardHeader
        title={
          <Typography variant="h6" sx={{ fontWeight: 700 }}>
            Recent Hate Comments
          </Typography>
        }
        subheader={
          <Typography variant="caption" sx={{ color: 'text.secondary' }}>
            Last detected instances with actions
          </Typography>
        }
        avatar={
          <Avatar sx={{ 
            bgcolor: '#3b2969',
            color: 'white ',
          }}>
            <WarningIcon />
          </Avatar>
        }
        sx={{
          borderBottom: '1px solid rgba(0,0,0,0.05)',
          background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.95) 100%)'
        }}
      />

      {/* Comments Container */}
      <Box sx={{
        p: 2,
        flex: 1,
        overflow: 'auto',
        display: 'grid',
        gap: 2,
        background: 'rgba(250,250,252,0.8)',
        '&::-webkit-scrollbar': {
          width: '6px',
        },
        '&::-webkit-scrollbar-thumb': {
          backgroundColor: 'rgba(0,0,0,0.1)',
          borderRadius: '3px',
        },
      }}>
        {comments.length > 0 ? (
          comments.map((comment, index) => (
            <CommentCard
              key={index}
              sx={{
                animation: `${fadeIn} 0.4s ease-out ${index * 0.1}s both`,
                '&::before': {
                  background: getSeverityColor(comment.severity)
                }
              }}
            >
              {/* Comment Text */}
              <Typography 
                variant="body1" 
                sx={{ 
                  mb: 2,
                  fontWeight: 500,
                  lineHeight: 1.5,
                  pl: 1
                }}
              >
                "{comment.text}"
              </Typography>

              {/* Metadata Section */}
              <Box sx={{
                display: 'flex',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: 1,
                pl: 1
              }}>
                {/* Topic Chip */}
                <Chip
                  label={comment.topic}
                  size="small"
                  sx={{ 
                    fontWeight: 600,
                    bgcolor: 'rgba(92, 26, 197, 0.08)',
                    color: '#3b2969'
                  }}
                />

                {/* Delete and Report Buttons */}
                <Box sx={{ flex: 1, display: 'flex', gap: 1 }}>
                  <Button
                    variant="contained"
                    color="error"
                    size="small"
                    onClick={() => onDelete(comment.id)}
                    sx={{
                      textTransform: 'none',
                      fontWeight: 600,
                      borderRadius: 20,
                      px: 2,
                      boxShadow: 'none',
                      '&:hover': {
                        backgroundColor: '#3b2969',
                        boxShadow: '0 2px 10px rgba(255, 77, 77, 0.5)',
                      }
                    }}
                  >
                    Delete
                  </Button>
                  <Button
                    variant="outlined"
                    color="primary"
                    size="small"
                    onClick={() => onReport(comment.id)}
                    sx={{
                      textTransform: 'none',
                      fontWeight: 600,
                      borderRadius: 20,
                      px: 2,
                      borderColor: 'primary.main',
                      '&:hover': {
                        borderColor: 'primary.dark',
                        backgroundColor: 'rgba(29, 161, 242, 0.1)',
                      }
                    }}
                  >
                    Report
                  </Button>
                </Box>

                {/* Timestamp */}
                <Typography 
                  variant="caption" 
                  sx={{ 
                    color: 'text.secondary',
                    fontWeight: 500
                  }}
                >
                  {formatDistanceToNow(new Date(comment.timestamp))} ago
                </Typography>
              </Box>
            </CommentCard>
          ))
        ) : (
          <Box sx={{ textAlign: 'center', py: 2 }}>
            <Typography variant="body1" sx={{ color: 'text.secondary' }}>
              No hate comments detected
            </Typography>
          </Box>
        )}
      </Box>

      {/* Footer */}
      <Box sx={{ 
        p: 1.5,
        borderTop: '1px solid rgba(0,0,0,0.05)',
        background: 'rgba(255,255,255,0.7)'
      }}>
        <Typography 
          variant="caption" 
          sx={{ 
            display: 'flex',
            alignItems: 'center',
            color: 'error.main',
            fontWeight: 600
          }}
        >
          <WarningIcon sx={{ fontSize: 16, mr: 1 }} />
          {comments.filter(c => c.severity === 'high').length} critical alerts in last 24 hours
        </Typography>
      </Box>
    </Card>
  );
}
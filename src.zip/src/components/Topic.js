import React from 'react';
import { Bar } from 'react-chartjs-2';
import { 
  Card, 
  CardHeader, 
  Box, 
  Typography,
  useTheme,
  Avatar,
  LinearProgress,
  Chip
} from '@mui/material';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend,
  Filler
} from 'chart.js';
import TimelineIcon from '@mui/icons-material/Timeline';
import { styled, keyframes } from '@mui/system';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

// Animation for the card entrance
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

// Styled card with animation
const AnimatedCard = styled(Card)(({ theme }) => ({
  borderRadius: '16px',
  boxShadow: '0 8px 32px rgba(31, 38, 135, 0.1)',
  backdropFilter: 'blur(4px)',
  WebkitBackdropFilter: 'blur(4px)',
  border: `1px solid rgba(255, 255, 255, 0.18)`,
  background: 'linear-gradient(145deg, #ffffff, #f8f9fa)',
  transition: 'all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
  animation: `${fadeIn} 0.6s ease-out forwards`,
  '&:hover': {
    transform: 'translateY(-8px)',
    boxShadow: '0 12px 40px rgba(31, 38, 135, 0.2)'
  }
}));

// Custom color palette with better contrast
const topicColors = [
  '#3b2969', // Primary color
  '#E91E63', // Pink for accent
  '#7775c1', // Lightest shade
  '#4285F4', // Keep blue tone
  
  '#0d47a1', // Dark blue tone
  '#FFAB00', // Yellow for contrast
  '#00BFA5', // Teal for variety
  '#FF5252', // Red for emphasis
  '#E91E63', // Pink for accent
  '#4a3c7f', // Slightly lighter shade
  '#2196F3', // Another blue tone
  '#594f95', // Lighter shade
  '#6862ab', // Even lighter shade
];

// Component: HateSpeechByTopicChart
export default function Topic({ posts, hateComments, isLoading }) {
  const theme = useTheme();

  if (isLoading) {
    return (
      <AnimatedCard>
        <CardHeader
          title={<Typography variant="h6" sx={{ fontWeight: 600 }}>Hate Speech by Topic</Typography>}
          subheader="Loading data..."
        />
        <Box sx={{ p: 3, height: 400, display: 'flex', alignItems: 'center' }}>
          <LinearProgress sx={{ width: '100%', height: 8, borderRadius: 4 }} />
        </Box>
      </AnimatedCard>
    );
  }

  // Aggregate hate speech counts by topic
  const hateSpeechByTopic = {};
  hateComments.forEach((comment) => {
    if (!hateSpeechByTopic[comment.topic]) {
      hateSpeechByTopic[comment.topic] = 0;
    }
    hateSpeechByTopic[comment.topic]++;
  });

  // Sort topics by count (descending)
  const sortedTopics = Object.entries(hateSpeechByTopic)
    .sort((a, b) => b[1] - a[1]);

  const labels = sortedTopics.map(([topic]) => topic);
  const dataValues = sortedTopics.map(([_, count]) => count);
  const totalComments = dataValues.reduce((sum, count) => sum + count, 0);

  const data = {
    labels: labels,
    datasets: [{
      label: 'Hate Comments',
      data: dataValues,
      backgroundColor: labels.map((_, i) => topicColors[i % topicColors.length]),
      hoverBackgroundColor: labels.map((_, i) => `${topicColors[i % topicColors.length]}CC`),
      borderRadius: 8,
      borderWidth: 0,
      barThickness: 'flex',
      maxBarThickness: 48,
      minBarLength: 4
    }]
  };

  return (
    <AnimatedCard>
      <CardHeader 
        title={
          <Typography variant="h6" sx={{ fontWeight: 700, letterSpacing: '0.5px' }}>
            Hate Speech Distribution
          </Typography>
        }
        subheader={
          <Typography variant="body2" sx={{ color: theme.palette.text.secondary }}>
            Breakdown by detected topic categories
          </Typography>
        }
        avatar={
          <Avatar
            sx={{
              bgcolor: 'rgba(66, 133, 244, 0.1)',
              color: '#4285F4',
              width: 48,
              height: 48,
              boxShadow: '0 4px 12px rgba(66, 133, 244, 0.2)'
            }}
          >
            <TimelineIcon fontSize="medium" />
          </Avatar>
        }
        sx={{
          borderBottom: `1px solid ${theme.palette.divider}`,
          background: 'linear-gradient(90deg, rgba(240,248,255,1) 0%, rgba(255,255,255,1) 100%)',
          py: 2.5
        }}
      />
      <Box sx={{ 
        p: 3, 
        height: 400,
        position: 'relative',
        '&:hover canvas': {
          transform: 'scale(1.01)'
        }
      }}>
        <Bar
          data={data}
          options={{
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false
              },
              tooltip: {
                backgroundColor: theme.palette.background.paper,
                titleColor: theme.palette.text.primary,
                bodyColor: theme.palette.text.secondary,
                borderColor: theme.palette.divider,
                borderWidth: 1,
                padding: 12,
                boxShadow: theme.shadows[3],
                usePointStyle: true,
                callbacks: {
                  label: (context) => {
                    const percentage = ((context.raw / totalComments) * 100).toFixed(1);
                    return `${context.dataset.label}: ${context.raw} (${percentage}%)`;
                  },
                  labelColor: (context) => {
                    return {
                      borderColor: 'transparent',
                      backgroundColor: topicColors[context.dataIndex % topicColors.length],
                      borderRadius: 4
                    };
                  }
                }
              }
            },
            scales: {
              x: {
                grid: {
                  display: false,
                  drawBorder: false
                },
                ticks: {
                  display: false
                }
              },
              y: {
                beginAtZero: true,
                grid: {
                  color: theme.palette.divider,
                  drawBorder: false
                },
                ticks: {
                  precision: 0,
                  font: {
                    size: 11,
                    weight: 500
                  },
                  color: theme.palette.text.secondary
                }
              }
            },
            interaction: {
              intersect: false,
              mode: 'index'
            },
            animation: {
              duration: 1000,
              easing: 'easeOutQuart'
            }
          }}
        />
      </Box>
      <Box sx={{
        px: 3,
        py: 2,
        borderTop: `1px solid ${theme.palette.divider}`,
        background: 'rgba(0,0,0,0.02)',
        display: 'flex',
        flexWrap: 'wrap',
        gap: 1,
        justifyContent: 'center'
      }}>
        {labels.map((label, index) => (
          <Chip
            key={index}
            label={`${label}: ${dataValues[index]}`}
            size="small"
            sx={{
              backgroundColor: `${topicColors[index % topicColors.length]}20`,
              color: topicColors[index % topicColors.length],
              border: `1px solid ${topicColors[index % topicColors.length]}40`,
              fontWeight: 500,
              '& .MuiChip-avatar': {
                backgroundColor: topicColors[index % topicColors.length]
              }
            }}
            avatar={
              <Avatar sx={{ 
                bgcolor: topicColors[index % topicColors.length],
                width: 16, 
                height: 16 
              }} />
            }
          />
        ))}
      </Box>
      <Box sx={{
        px: 3,
        py: 1.5,
        borderTop: `1px solid ${theme.palette.divider}`,
        background: 'rgba(0,0,0,0.03)',
        textAlign: 'center'
      }}>
        <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>
          {totalComments} total hate comments detected across {labels.length} topics
        </Typography>
      </Box>
    </AnimatedCard>
  );
}
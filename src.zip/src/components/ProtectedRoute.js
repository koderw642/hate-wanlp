import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';

const ProtectedRoute = ({ children }) => {
    const location = useLocation();

    // Check if the token exists in localStorage
    const isAuthenticated = !!localStorage.getItem('reddit_token');

    if (!isAuthenticated) {
        // Redirect to login if not authenticated
        return <Navigate to="/login" replace state={{ from: location }} />;
    }

    // Render the protected content if authenticated
    return children;
};

export default ProtectedRoute;